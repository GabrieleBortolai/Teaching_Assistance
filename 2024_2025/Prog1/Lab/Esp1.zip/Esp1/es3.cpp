#include <iostream>

using namespace std;

int main(){
   
  double a,b;

  cout<<"Inserire la base e l'altezza"<<endl;
  cin>>a;
  cin>>b;

  cout<<"il perimetro vale: "<<2*(a+b)<<" L'area vale: "<<a*b<<endl;
  
  return 0;
}

