#include <iostream>

using namespace std;

int main(){
   
  double a,b;

  cout<<"Inserire le variabili A e B"<<endl;
  cin>>a;
  cin>>b;

  cout<<"La somma vale: "<<a+b<<" La differenza vale: "<<a-b<<" Il prodotto vale: "<<a*b<<" La divisione vale: "<<a/b<<endl;
  
  return 0;
}

